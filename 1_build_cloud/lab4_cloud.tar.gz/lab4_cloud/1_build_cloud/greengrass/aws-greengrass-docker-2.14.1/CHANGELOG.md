# Changelog

## v2.1.0

Initial Greengrass in Docker launch with Greengrass v2.1.0
Greengrass v2.1.0 release notes: https://docs.aws.amazon.com/greengrass/v2/developerguide/greengrass-release-2021-04-26.html

## v2.2.0

Greengrass in Docker release with Greengrass v2.2.0
Includes bug fixes and improvements 
Greengrass v2.2.0 release notes: https://docs.aws.amazon.com/greengrass/v2/developerguide/greengrass-release-2021-06-18.html

## v2.3.0

Greengrass in Docker release with Greengrass v2.3.0
Includes bug fixes and improvements
Greengrass v2.3.0 release notes: https://docs.aws.amazon.com/greengrass/v2/developerguide/greengrass-release-2021-06-29.html

## v2.4.0

Greengrass in Docker release with Greengrass v2.4.0
Includes bug fixes and improvements
Greengrass v2.4.0 release notes: https://docs.aws.amazon.com/greengrass/v2/developerguide/greengrass-release-2021-08-03.html

## v2.5.2

Greengrass in Docker release with Greengrass v2.5.2
Includes bug fixes and improvements
Greengrass v2.5.2 release notes: https://docs.aws.amazon.com/greengrass/v2/developerguide/greengrass-release-2021-12-03.html


## v2.5.3

Greengrass in Docker release with Greengrass v2.5.3
Includes bug fixes and improvements
Greengrass v2.5.3 release notes:https://docs.aws.amazon.com/greengrass/v2/developerguide/greengrass-release-2022-01-06.html

## v2.5.4

Greengrass in Docker release with Greengrass v2.5.4
Includes bug fixes and improvements
Greengrass v2.5.4 release notes:https://docs.aws.amazon.com/greengrass/v2/developerguide/greengrass-release-2022-03-23.html
